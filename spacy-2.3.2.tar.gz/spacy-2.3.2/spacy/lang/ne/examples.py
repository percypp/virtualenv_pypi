# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.ne.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "एप्पलले अमेरिकी स्टार्टअप १ अर्ब डलरमा किन्ने सोच्दै छ",
    "स्वायत्त कारहरूले बीमा दायित्व निर्माताहरु तिर बदल्छन्",
    "स्यान फ्रांसिस्कोले फुटपाथ वितरण रोबोटहरु प्रतिबंध गर्ने विचार गर्दै छ",
    "लन्डन यूनाइटेड किंगडमको एक ठूलो शहर हो।",
    "तिमी कहाँ छौ?",
    "फ्रान्स को राष्ट्रपति को हो?",
    "संयुक्त राज्यको राजधानी के हो?",
    "बराक ओबामा कहिले कहिले जन्मेका हुन्?",
]
