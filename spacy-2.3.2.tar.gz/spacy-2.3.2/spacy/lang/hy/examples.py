# coding: utf8
from __future__ import unicode_literals

"""
Example sentences to test spaCy and its language models.
>>> from spacy.lang.hy.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Լոնդոնը Միացյալ Թագավորության մեծ քաղաք է։",
    "Ո՞վ է Ֆրանսիայի նախագահը։",
    "Ո՞րն է Միացյալ Նահանգների մայրաքաղաքը։",
    "Ե՞րբ է ծնվել Բարաք Օբաման։",
]
