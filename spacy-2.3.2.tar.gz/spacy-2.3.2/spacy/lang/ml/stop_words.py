# coding: utf8
from __future__ import unicode_literals


STOP_WORDS = set(
    """
അത്
ഇത്
ആയിരുന്നു
ആകുന്നു
വരെ
അന്നേരം
അന്ന്
ഇന്ന്
ആണ്
""".split()
)
