"""Run smoke tests"""

import torchtext
import torchtext.version  # noqa: F401

print("torchtext version is ", torchtext.__version__)
