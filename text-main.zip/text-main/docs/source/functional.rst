.. role:: hidden
    :class: hidden-section

torchtext.functional
===========================

.. automodule:: torchtext.functional
.. currentmodule:: torchtext.functional

to_tensor
---------

.. autofunction:: to_tensor


truncate
--------

.. autofunction:: truncate


add_token
---------

.. autofunction:: add_token

str_to_int
----------

.. autofunction:: str_to_int
