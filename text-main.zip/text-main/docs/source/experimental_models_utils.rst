.. role:: hidden
    :class: hidden-section

torchtext.experimental.models.utils
===================================

.. automodule:: torchtext.experimental.models.utils
.. currentmodule:: torchtext.experimental.models.utils

:hidden:`count_model_param`
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: count_model_param
