.. role:: hidden
    :class: hidden-section

torchtext.experimental.vocab_factory
====================================

.. automodule:: torchtext.experimental.vocab_factory
.. currentmodule:: torchtext.experimental.vocab_factory

:hidden:`load_vocab_from_file`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: load_vocab_from_file

:hidden:`build_vocab_from_text_file`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: build_vocab_from_text_file
